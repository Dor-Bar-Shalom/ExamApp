﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Exam_Management_System.ViewModel
{
    //act as a ViewModel for the main window or shell of the application:
    public class ShellViewModel : ObservableObject
    {
        private object currentViewModel;
        public object CurrentViewModel { get => currentViewModel; set { SetProperty(ref currentViewModel, value); } }

        public ShellViewModel()
        {

        }//

        //takes a ViewModel object and sets it to the CurrentViewModel property,
        //which then updates the UI to display the corresponding View:
        public void SwitchVM(object vm)
        {
            CurrentViewModel = vm;
        }
    }
}
