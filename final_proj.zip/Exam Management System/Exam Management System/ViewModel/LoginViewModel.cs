﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Exam_Management_System.ViewModel
{
    public class LoginViewModel : ObservableObject
    {
        public LoginViewModel()
        {

        }
    }
}
