﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;
using Exam_Management_System.Models;
using Exam_Management_System.Services;
using Microsoft.Win32;
using Newtonsoft.Json;
using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;

namespace Exam_Management_System.ViewModel.TeacherViewModels
{

    //contains methods to handle user interactions with a GUI application for managing exams:
    public class NewExamViewModel : ObservableObject
    {
        private Exam _exams = new Exam();
        public Exam Exams { get => _exams; set => SetProperty(ref _exams, value); }

        public IRelayCommand SaveOnDeviceCommand { get; set; }
        public IRelayCommand UploadToServerCommand { get; set; }
        public IRelayCommand EditCommand { get; set; }
        public IRelayCommand ViewCommand { get; set; }
        public IRelayCommand DeleteCommand { get; set; }
        public IRelayCommand CancelCommand { get; set; }
        public IRelayCommand AddQuestionCommand { get; set; }
        public IRelayCommand LogoutCommand { get; set; }
        public EmsTeacherApi emsTeacherApi { get; set; }

        //Constructor:
        public NewExamViewModel()
        {
            SaveOnDeviceCommand = new RelayCommand(saveOnDevice);
            UploadToServerCommand = new RelayCommand(uploadToServer);
            EditCommand = new RelayCommand<QuestionModel>(model => edit(model));
            DeleteCommand = new RelayCommand<QuestionModel>(model => delete(model));
            ViewCommand = new RelayCommand<QuestionModel>(model => preview(model));
            CancelCommand = new RelayCommand(cancel);
            AddQuestionCommand = new RelayCommand(addQuestion);
            LogoutCommand = new RelayCommand(logout);
            emsTeacherApi = new EmsTeacherApi();
        }//

        //clears the JWT token and sends a message to open the LoginViewModel:
        private void logout()
        {
            Properties.Settings.Default.JWT = string.Empty;//clear token
            WeakReferenceMessenger.Default.Send(new LoginViewModel());
        }

        //removes the given question from the exam:
        private void delete(QuestionModel? model)
        {
            Exams.Questions.RemoveAt(Exams.Questions.IndexOf(model));
        }

        //opens a dialog to preview the given question:
        private async void preview(QuestionModel? model)
        {
            try
            {
                var vm = new TeacherQuestionPreviewViewModel();
                var modelStr = JsonConvert.SerializeObject(model);
                vm.Question = JsonConvert.DeserializeObject<QuestionModel>(modelStr);

                if (vm.Question.IsRandomOptions == true)
                {
                    Random rng = new Random();
                    vm.Question.Options = new ObservableCollection<string>(vm.Question.Options.OrderBy(a => rng.Next()).ToList());
                }

                var result = await MaterialDesignThemes.Wpf.DialogHost.Show(vm, "DialogHost");
            }
            catch (Exception err) { Debug.WriteLine(err.Message); }
        }

        //opens a dialog to edit the given question:
        private async void edit(QuestionModel? model)
        {
            try
            {
                var vm = new AddNewQuestionViewModel();
                vm.Question = model;
                var result = await MaterialDesignThemes.Wpf.DialogHost.Show(vm, "DialogHost");
                if (result is bool bol && bol == true)
                    Exams.Questions[Exams.Questions.IndexOf(model)] = model;
            }
            catch (Exception err) { Debug.WriteLine(err.Message); }
        }

        //opens a dialog to add a new question to the exam:
        private async void addQuestion()
        {
            try
            {
                var vm = new AddNewQuestionViewModel();
                var result = await MaterialDesignThemes.Wpf.DialogHost.Show(vm, "DialogHost");
                if (result is bool bol && bol == true)
                    Exams.Questions.Add(vm.Question);
            }
            catch (Exception err) { Debug.WriteLine(err.Message); }
        }

        //validates the exam details and uploads the exam to the server if it passes the validation:
        private async void uploadToServer()
        {
            if (string.IsNullOrEmpty(Exams.Name))
            {
                MessageBox.Show("Exam Name should not be empty.");
                return;
            }

            if (Exams.Date == null)
            {
                MessageBox.Show("Exam Start Date should not be empty.");
                return;
            }

            if (string.IsNullOrEmpty(Exams.BeginningTime) || string.IsNullOrEmpty(Exams.EndTime))
            {
                MessageBox.Show("Exam Beginning Time and Exam EndTime should not be empty.");
                return;
            }

            DateTime startTime = Convert.ToDateTime(Exams.BeginningTime, new CultureInfo("en-US"));
            DateTime endTime = Convert.ToDateTime(Exams.EndTime, new CultureInfo("en-US"));
            var timespan = endTime - startTime;

            if (timespan.Hours < 0)
            {
                MessageBox.Show("Exam End Time should not be greater than Start time");
                return;
            }

            if (Exams.ID == -1)
            {
                var jsonStr = JsonConvert.SerializeObject(Exams);
                var isAdded = await emsTeacherApi.AddExamAsync(new ExamModel { ExamJson = jsonStr });
                if (isAdded)
                    WeakReferenceMessenger.Default.Send(new ChangeViewModelMessage(new TeacherHomeViewModel()));
            }

            else
            {
                var jsonStr = JsonConvert.SerializeObject(Exams);
                var isAdded = await emsTeacherApi.UpdateExamAsync(new ExamModel { ExamJson = jsonStr });
                if (isAdded)
                    WeakReferenceMessenger.Default.Send(new ChangeViewModelMessage(new TeacherHomeViewModel()));
            }
        }

        //saves the exam details as a JSON file on the local device:
        private void saveOnDevice()
        {
            var jsonStr = JsonConvert.SerializeObject(Exams);

            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Json file (*.Json)|*.Json";
            if (saveFileDialog.ShowDialog() == true)
            {
                try
                {
                    using (StreamWriter writer = new StreamWriter(saveFileDialog.FileName))
                        writer.Write(jsonStr);
                }
                catch (Exception err) { Debug.WriteLine(err); }
                WeakReferenceMessenger.Default.Send(new ChangeViewModelMessage(new TeacherHomeViewModel()));
            }//
        }

        //called when the user clicks on the cancel button in the New Exam view,
        //and it clears all the fields of the exam being created or edited:
        private void cancel()
        {
            WeakReferenceMessenger.Default.Send(new ChangeViewModelMessage(new TeacherHomeViewModel()));
        }
    }
}
