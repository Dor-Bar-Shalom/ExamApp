﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;
using Exam_Management_System.Models;
using Microsoft.Win32;
using Newtonsoft.Json;
using System.Diagnostics;
using System.IO;
using System;
using Exam_Management_System.Services;
using System.Collections.ObjectModel;

namespace Exam_Management_System.ViewModel.TeacherViewModels
{

    //serve as the view model for the teacher's home page in an exam management system:
    public class TeacherHomeViewModel : ObservableObject
    {
        public IRelayCommand NewExamCommand { get; set; }
        public IRelayCommand LoadFileCommand { get; set; }
        public IRelayCommand LogoutCommand { get; set; }
        public IRelayCommand SearchCommand { get; set; }
        public IRelayCommand UpdateCommand { get; set; }
        public IRelayCommand StatsCommand { get; set; }

        public EmsTeacherApi emsTeacherApi { get; set; }

        private ObservableCollection<Exam> _searchExams = new ObservableCollection<Exam>();
        public ObservableCollection<Exam> SearchExams { get => _searchExams; set => SetProperty(ref _searchExams, value); }

        //Constructor:
        public TeacherHomeViewModel()
        {
            NewExamCommand = new RelayCommand(newExam);
            LoadFileCommand = new RelayCommand(loadFromFile);
            LogoutCommand = new RelayCommand(logout);
            UpdateCommand = new RelayCommand<Exam>(exam => update(exam));
            StatsCommand = new RelayCommand<Exam>(exam => stats(exam));
            SearchCommand = new RelayCommand<string>(searchTxt => search(searchTxt));
            emsTeacherApi = new EmsTeacherApi();
        }//

        //sends a message to the WeakReferenceMessenger to change the view to the edit exam page with the selected exam data:
        private void update(Exam exam)
        {
            var vm = new NewExamViewModel();
            vm.Exams = exam;
            WeakReferenceMessenger.Default.Send(new ChangeViewModelMessage(vm));
        }

        //sends a request to the EmsTeacherApi class for statistics on the selected exam and sends the
        //resulting StudentStatsModel object to the WeakReferenceMessenger to display the exam statistics page:
        private async void stats(Exam exam)
        {
            var stats = await emsTeacherApi.ExamStatsAsync(exam.ID);
            stats.ExamName = exam.Name;
            WeakReferenceMessenger.Default.Send(stats);
        }

        //sends a search query to the EmsTeacherApi class with the given search text,
        //receives a collection of matching Exam objects, and updates the SearchExams property with the results:
        private async void search(string searchTxt)
        {
            if (!string.IsNullOrEmpty(searchTxt))
                SearchExams = new ObservableCollection<Exam>(await emsTeacherApi.SearchExamAsync(searchTxt));
        }

        //clears the JWT token stored in the application's settings and sends a message to the
        //WeakReferenceMessenger to change the view to the login page:
        private void logout()
        {
            Properties.Settings.Default.JWT = string.Empty;//clear token
            WeakReferenceMessenger.Default.Send(new LoginViewModel());
        }

        //displays a file dialog to load an exam from a JSON file, deserializes the JSON data into an Exam object,
        //and sends a message to the WeakReferenceMessenger to change the view to the new exam page
        //with the loaded exam data:
        private void loadFromFile()
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.Filter = "Json file (*.json)|*.json";
            if (fileDialog.ShowDialog() == true)
            {
                try
                {
                    using (StreamReader reader = new StreamReader(fileDialog.FileName))
                    {
                        var JsonStr = reader.ReadToEnd();
                        var examData = JsonConvert.DeserializeObject<Exam>(JsonStr);
                        var vm = new NewExamViewModel();
                        vm.Exams = examData;
                        WeakReferenceMessenger.Default.Send(new ChangeViewModelMessage(vm));
                    }
                }
                catch (Exception err) { Debug.WriteLine(err.Message); }
            }//
        }

        //sends a message to the WeakReferenceMessenger to change the view to the new exam page:
        private void newExam()
        {
            WeakReferenceMessenger.Default.Send(new ChangeViewModelMessage(new NewExamViewModel()));
        }// 

    }
}
