﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;
using Exam_Management_System.Models;
using Exam_Management_System.Services;
using System.Windows;

namespace Exam_Management_System.ViewModel.TeacherViewModels
{
    //provide the ViewModel logic for the Teacher Login View:
    public class TeacherLoginViewModel : ObservableObject
    {
        //Properties:
        private LoginModel _loginModel = new LoginModel { UserType = UserType.Teacher };
        public LoginModel LoginModel { get => _loginModel; set => SetProperty(ref _loginModel, value); }

        public IRelayCommand LoginCommand { get; set; }
        public EmsTeacherApi emsTeacherApi { get; set; }

        private bool _isLogin = true;
        public bool IsLogin { get => _isLogin; set => SetProperty(ref _isLogin, value); }

        public TeacherLoginViewModel()
        {
            LoginCommand = new RelayCommand(login);
            emsTeacherApi = new EmsTeacherApi();
        }

        //attempts to log in the user using the emsTeacherApi object to make a call to the backend server.
        //It first checks that the UserName and Password fields are not empty,
        //then it sets the IsLogin property to false to show the user that login is in progress.
        //After the login request is sent, if the response from the server is successful,
        //it sends a message to the application to switch the view to the teacher home page,
        //passing the LoginModel as a parameter. If the login request fails, it does nothing and sets IsLogin back to true.
        private async void login()
        {
            IsLogin = false;

            if (string.IsNullOrEmpty(LoginModel.UserName) || string.IsNullOrEmpty(LoginModel.Password))
            {
                MessageBox.Show("fields can't be empty");
                IsLogin = true;
                return;
            }

            var isLoggedin = await emsTeacherApi.LoginAsync(LoginModel);
            if (isLoggedin)
                WeakReferenceMessenger.Default.Send(LoginModel);

            IsLogin = true;
        }//
    }
}
