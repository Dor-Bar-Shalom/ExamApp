﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Exam_Management_System.Models;
using Exam_Management_System.Services;
using System;
using System.Windows;

namespace Exam_Management_System.ViewModel.TeacherViewModels
{
    //handle the view logic for the teacher sign-up functionality of the Exam Management System application:
    public class TeacherSignupViewModel : ObservableObject
    {
        //properties:
        private UserModel _user = new UserModel();
        public UserModel User { get => _user; set => SetProperty(ref _user, value); }

        public IRelayCommand SignUpCommand { get; set; }
        public EmsTeacherApi emsTeacherApi { get; set; }

        public Action CloseWin = null;

        private bool _isSignup = true;
        public bool IsSignup { get => _isSignup; set => SetProperty(ref _isSignup, value); }

        //Constructor:
        public TeacherSignupViewModel()
        {
            SignUpCommand = new RelayCommand(signUp);
            emsTeacherApi = new EmsTeacherApi();
        }

        //called when the "Sign Up" button is clicked. It validates the user input, sends a sign-up request to the API,
        //and closes the sign-up window if the sign-up is successful.
        private async void signUp()
        {
            IsSignup = false;

            if (string.IsNullOrEmpty(User.UserName) || string.IsNullOrEmpty(User.Password) ||
                string.IsNullOrEmpty(User.ConfirmPassword) || string.IsNullOrEmpty(User.FirstName) || string.IsNullOrEmpty(User.LastName))
            {
                IsSignup = true;
                MessageBox.Show("one or more fields empty");
                return;
            }

            else if (User.Password != User.ConfirmPassword)
            {
                IsSignup = true;
                MessageBox.Show("Password should match");
                return;
            }

            var isSignedUp = await emsTeacherApi.SignUpAsync(User);
            if (isSignedUp)
                CloseWin?.Invoke();

            isSignedUp = true;
        }
    }
}
