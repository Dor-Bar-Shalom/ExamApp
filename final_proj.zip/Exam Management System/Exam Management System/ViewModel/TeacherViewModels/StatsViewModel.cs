﻿using CommunityToolkit.Mvvm.ComponentModel;
using LiveChartsCore.SkiaSharpView.Painting;
using LiveChartsCore.SkiaSharpView;
using LiveChartsCore;
using SkiaSharp;
using Exam_Management_System.Models;
using LiveChartsCore.Measure;

namespace Exam_Management_System.ViewModel.TeacherViewModels
{
    [ObservableObject]

    //provide a view model for displaying statistics related to student exam results in a
    //chart format using the LiveChartsCore library.
    public partial class StatsViewModel
    {
        public StudentStatsModel StudentStats { get; set; } = new StudentStatsModel();

        public ColumnSeries<StudentExamStats> Stats { get; set; }

        public ISeries[] Series { get; set; }

        public Axis[] YAxes { get; set; } =
        {
        new Axis { MinLimit = 0, MaxLimit = 100 }
        };

        //Constructor 
        public StatsViewModel()
        {

        }

        //creates a new ColumnSeries object and sets its properties.
        //It then sets the Series property to an array containing only the new ColumnSeries object.
        //This function is called to set up the chart data before it is displayed.
        public void setSeris()
        {
            Stats = new ColumnSeries<StudentExamStats>
            {
                Values = StudentStats.ExamStats,
                DataLabelsPaint = new SolidColorPaint(new SKColor(30, 30, 30)),
                TooltipLabelFormatter = point => $"Percentage: {point.Model?.Percentage}",
                DataLabelsFormatter = point => $"{point.Model?.StudentName}",
                DataLabelsPosition = DataLabelsPosition.End,
                Mapping = (stats, point) =>
                {
                    point.PrimaryValue = stats.Percentage;
                    point.SecondaryValue = point.Context.Entity.EntityIndex;
                },
                Fill = new SolidColorPaint(SKColors.CornflowerBlue),
                IgnoresBarPosition = true
            };
            Series = new ISeries[] { Stats };
        }//

    }
}
