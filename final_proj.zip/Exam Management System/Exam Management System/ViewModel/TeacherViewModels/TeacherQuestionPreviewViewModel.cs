﻿using CommunityToolkit.Mvvm.ComponentModel;
using Exam_Management_System.Models;

namespace Exam_Management_System.ViewModel.TeacherViewModels
{
    //provide a view model for previewing a question for a teacher in the exam management system:
    public class TeacherQuestionPreviewViewModel : ObservableObject
    {
        //property:
        private QuestionModel _question;
        public QuestionModel Question
        {
            get => _question; set
            {
                SetProperty(ref _question, value);
            }
        }
        public TeacherQuestionPreviewViewModel()
        {

        }
    }
}
//short note:
//This class contains a single property Question which is of type QuestionModel and is used to hold the
//question data that will be displayed in the preview.
//The constructor of the class is empty as there is no initialization or setup required for this view model.
