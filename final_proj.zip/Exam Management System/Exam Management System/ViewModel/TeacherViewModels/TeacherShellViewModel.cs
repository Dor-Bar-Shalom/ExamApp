﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Messaging;
using Exam_Management_System.Models;

namespace Exam_Management_System.ViewModel.TeacherViewModels
{
    //manage the current view model displayed in the teacher's shell:
    public class TeacherShellViewModel : ObservableObject
    {
        //properties:
        private object currentViewModel;
        public object CurrentViewModel { get => currentViewModel; set { SetProperty(ref currentViewModel, value); } }

        //Constructor:
        public TeacherShellViewModel()
        {
            currentViewModel = new TeacherHomeViewModel();
            WeakReferenceMessenger.Default.Register<ChangeViewModelMessage>(this, (r, m) => receiveM(m));
        }//


        //message handler method that updates the currentViewModel property with the value of the ChangeViewModelMessage.
        //This allows the TeacherShellView to switch between different view models based on the messages sent.
        private void receiveM(ChangeViewModelMessage message)
        {
            CurrentViewModel = message.Value;
        }//
    }
}
