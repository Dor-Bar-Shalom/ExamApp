﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Exam_Management_System.Models;
using System;

namespace Exam_Management_System.ViewModel.TeacherViewModels
{
    //provide the view model for the "Add New Question" functionality in the teacher's sectio
    public class AddNewQuestionViewModel : ObservableObject
    {
        private QuestionModel _question = new QuestionModel();
        public QuestionModel Question { get => _question; set => SetProperty(ref _question, value); }

        private string _opsText = string.Empty;
        public string OpsText { get => _opsText; set => SetProperty(ref _opsText, value); }

        public IRelayCommand SaveOpsCommand { get; set; }
        public IRelayCommand DeleteCommand { get; set; }

        //Constructor:
        public AddNewQuestionViewModel()
        {
            SaveOpsCommand = new RelayCommand<string>(ops => saveOps(ops));
            DeleteCommand = new RelayCommand<string>(model => delete(model));
        }//

        //removes an option from the Options list of the Question property.
        private void delete(string? model)
        {
            Question.Options.RemoveAt(Question.Options.IndexOf(model));
        }

        //adds the option text to the Options list of the Question property and clears the OpsText property.
        private void saveOps(string ops)
        {
            Question.Options?.Add(ops);
            OpsText = string.Empty;
        }

    }
}
