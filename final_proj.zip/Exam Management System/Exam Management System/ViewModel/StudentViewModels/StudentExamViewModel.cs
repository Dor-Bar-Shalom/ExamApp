﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;
using Exam_Management_System.Models;
using Exam_Management_System.Services;
using System;
using System.Windows;

namespace Exam_Management_System.ViewModel.StudentViewModels
{

    //handle the logic and data binding for displaying the exam questions and answers to the student and provide them
    //with the ability to navigate through the exam, select answers, and submit the exam.
    public class StudentExamViewModel : ObservableObject
    {
        private Exam _exams = new Exam();
        public Exam Exams { get => _exams; set => SetProperty(ref _exams, value); }

        private QuestionModel _question = new QuestionModel();
        public QuestionModel Question
        {
            get => _question; set
            {
                SetProperty(ref _question, value);
            }
        }

        private bool _isSubmit = true;
        public bool IsSubmit { get => _isSubmit; set => SetProperty(ref _isSubmit, value); }

        private int currentIndex = 0;

        private string _curState = string.Empty;
        public string CurrentState { get => _curState; set => SetProperty(ref _curState, value); }

        private string _answered = string.Empty;
        public string Answered { get => _answered; set => SetProperty(ref _answered, value); }

        private string _selectedVal = string.Empty;
        public string SelectedVal
        {
            get => _selectedVal; set
            {

                SetProperty(ref _selectedVal, value);
                getAnsweredQuestions();
            }
        }

        public IRelayCommand NextCommand { get; set; }
        public IRelayCommand PrevCommand { get; set; }
        public IRelayCommand CancelCommand { get; set; }
        public IRelayCommand SubmitCommand { get; set; }

        private EmsStudentApi emsStudentApi = new EmsStudentApi();

        //Constructor:
        public StudentExamViewModel()
        {
            WeakReferenceMessenger.Default.Register<Exam>(this, (r, m) => receiveM(m));
            NextCommand = new RelayCommand(next);
            PrevCommand = new RelayCommand(prev);
            CancelCommand = new RelayCommand(cancel);
            SubmitCommand = new RelayCommand(submit);
        }

        //It submits the exam to the API and displays a message box showing the exam has been completed.
        //Then, it sends a message to switch to the "StudentHomeViewModel".
        private async void submit()
        {
            IsSubmit = false;
            var submitted = await emsStudentApi.SubmitExam(Exams);
            if (submitted)
            {
                MessageBox.Show("Exam Completed");
                WeakReferenceMessenger.Default.Send(new ChangeViewModelMessage(new StudentHomeViewModel()));
            }
            IsSubmit = true;//
        }

        //The next two functions called when the student clicks on the "Next" and "Previous" buttons respectively:
        private void next()
        {
            if (currentIndex < Exams.Questions.Count - 1)
            {
                currentIndex++;
                Question = Exams.Questions[currentIndex];
                CurrentState = $"{currentIndex + 1}\\{Exams.Questions.Count}";
            }
        }

        private void prev()
        {
            if (currentIndex > 0)
            {
                --currentIndex;
                Question = Exams.Questions[currentIndex];
                CurrentState = $"{currentIndex + 1}\\{Exams.Questions.Count}";
            }
        }

        // responsible for counting the number of answered questions in an exam and updating the Answered property accordingly.
        // It iterates through all the questions in the exam and checks if the SelectedIndex property of the question is greater
        // than -1 (indicating that the question has been answered), and increments a counter if so.
        // Finally, it updates the Answered property to display the number of answered questions out of the total number of questions in the exam.
        private void getAnsweredQuestions()
        {
            int answered = 0;
            foreach (var question in Exams.Questions)
            {
                if (question.SelectedIndex > -1)
                    answered++;
            }
            Answered = $"{answered}\\{Exams.Questions.Count}";
        }

        //called when the student clicks on the "Cancel" button.
        //It sends a message to switch to the "StudentHomeViewModel":
        private void cancel()
        {
            WeakReferenceMessenger.Default.Send(new ChangeViewModelMessage(new StudentHomeViewModel()));
        }

        //called when a message of type Exam is received. It sets the exam object and initializes the current
        //index, current state, and answered properties. Then, it sets the current question to the first question in the exam.
        private void receiveM(Exam m)
        {
            Exams = m;
            currentIndex = 0;
            if (Exams.Questions.Count > 0)
                Question = Exams.Questions[currentIndex];

            CurrentState = $"{currentIndex + 1}\\{Exams.Questions.Count}";
            Answered = $"{0}\\{Exams.Questions.Count}";
        }//
    }
}
