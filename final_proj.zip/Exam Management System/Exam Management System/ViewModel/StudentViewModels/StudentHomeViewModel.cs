﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;
using Exam_Management_System.Models;
using Exam_Management_System.Services;
using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Windows;

namespace Exam_Management_System.ViewModel.StudentViewModels
{

    //serve as the view model for the student home page in an Exam Management System application.
    public class StudentHomeViewModel : ObservableObject
    {
        public IRelayCommand SearchCommand { get; set; }
        public IRelayCommand LogoutCommand { get; set; }
        public IRelayCommand StartExamCommand { get; set; }

        public EmsStudentApi emsStudentApi { get; set; }

        private ObservableCollection<Exam> _searchExams = new ObservableCollection<Exam>();
        public ObservableCollection<Exam> SearchExams { get => _searchExams; set => SetProperty(ref _searchExams, value); }

        private string _username = string.Empty;
        public string Username { get => _username; set => SetProperty(ref _username, value); }

        //Constructor:
        public StudentHomeViewModel()
        {
            StartExamCommand = new RelayCommand<Exam>(exam => startExam(exam));
            LogoutCommand = new RelayCommand(logout);
            SearchCommand = new RelayCommand<string>(searchTxt => search(searchTxt));
            emsStudentApi = new EmsStudentApi();
            Username = Properties.Settings.Default.UserName;
        }//

        //called when the user clicks the "Start Exam" button. It checks if the exam has already been taken by the student.
        //If not, it checks if the exam is available to be taken. If the exam is available, it randomizes the order of the
        //questions and options (if specified), and sends a message to the view to switch to the StudentExamViewModel
        //and pass the exam object to it.
        private async void startExam(Exam exam)
        {
            var isnottaken = await emsStudentApi.ExamInfoAsync(exam.ID);
            if (isnottaken)
            {
                DateTime startTime = Convert.ToDateTime(exam.BeginningTime, new CultureInfo("en-US"));
                DateTime endTime = Convert.ToDateTime(exam.EndTime, new CultureInfo("en-US"));

                if (exam.Date.ToShortDateString() != DateTime.Now.ToShortDateString())
                {
                    MessageBox.Show($"Exam doesn't begin till {exam.Date.ToShortDateString()} {exam.BeginningTime}");
                    return;
                }

                if (DateTime.Now < startTime)
                {
                    MessageBox.Show($"Exam doesn't begin till {exam.Date.ToShortDateString()} {exam.BeginningTime}");
                    return;
                }

                else if (DateTime.Now > endTime)
                {
                    MessageBox.Show($"Exam can't be accessed ended at {exam.Date.ToShortDateString()} {exam.EndTime}");
                    return;
                }

                //random questions
                if (exam.IsRandomOrderYes)
                {
                    Random rng = new Random();
                    exam.Questions = new ObservableCollection<QuestionModel>(exam.Questions.OrderBy(a => rng.Next()).ToList());
                }

                //random options
                foreach (var ex in exam.Questions)
                {
                    if (ex.IsRandomOptions)
                    {
                        Random rng = new Random();
                        ex.Options = new ObservableCollection<string>(ex.Options.OrderBy(a => rng.Next()).ToList());
                    }
                }//

                WeakReferenceMessenger.Default.Send(new ChangeViewModelMessage(new StudentExamViewModel()));
                WeakReferenceMessenger.Default.Send(exam);
            }
            else
                MessageBox.Show("Exam already taken by you.");
        }

        //called when the user enters text in the search box and presses the "Search" button.
        //It searches for exams that match the search query using the emsStudentApi object and sets
        //the SearchExams property to the search results.
        private async void search(string searchTxt)
        {
            if (!string.IsNullOrEmpty(searchTxt))
                SearchExams = new ObservableCollection<Exam>(await emsStudentApi.SearchExamAsync(searchTxt));
        }

        //called when the user clicks the "Logout" button. It clears the JWT token from the application settings
        //and sends a message to the view to switch to the LoginViewModel.
        private void logout()
        {
            Properties.Settings.Default.JWT = string.Empty;//clear token
            WeakReferenceMessenger.Default.Send(new LoginViewModel());
        }

    }
}
