﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;
using Exam_Management_System.Models;
using Exam_Management_System.Services;
using System.Windows;

namespace Exam_Management_System.ViewModel.StudentViewModels
{

    //serve as the view model for the student login page of the Exam Management System.
    public class StudentLoginViewModel : ObservableObject
    {
        private LoginModel _loginModel = new LoginModel { UserType = UserType.Student };
        public LoginModel LoginModel { get => _loginModel; set => SetProperty(ref _loginModel, value); }

        public IRelayCommand LoginCommand { get; set; }
        public EmsStudentApi emsStudentApi { get; set; }

        private bool _isLogin = true;
        public bool IsLogin { get => _isLogin; set => SetProperty(ref _isLogin, value); }

        //Constructor:
        public StudentLoginViewModel()
        {
            LoginCommand = new RelayCommand(login);
            emsStudentApi = new EmsStudentApi();
        }

        //called when the user clicks the login button. It first checks if the username and password fields are not empty,
        //and if they are, displays an error message. If the fields are not empty, it calls the LoginAsync() method of emsStudentApi
        //to check if the credentials are valid. If the credentials are valid, it sends a message using WeakReferenceMessenger to
        //notify other parts of the application that the user has successfully logged in.
        //Finally, it resets the IsLogin property to true, allowing the login button to be enabled again.
        private async void login()
        {
            IsLogin = false;

            if (string.IsNullOrEmpty(LoginModel.UserName) || string.IsNullOrEmpty(LoginModel.Password))
            {
                MessageBox.Show("fields can't be empty");
                IsLogin = true;
                return;
            }

            var isLoggedin = await emsStudentApi.LoginAsync(LoginModel);
            if (isLoggedin)
                WeakReferenceMessenger.Default.Send(LoginModel);

            IsLogin = true;
        }//
    }
}
