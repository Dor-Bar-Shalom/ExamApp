﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Exam_Management_System.Models;
using Exam_Management_System.Services;
using System;
using System.Windows;

namespace Exam_Management_System.ViewModel.StudentViewModels
{

    //handle the logic and functionality for the student sign-up view in an exam management system.
    public class StudentSignupViewModel : ObservableObject
    {
        private UserModel _user = new UserModel();
        public UserModel User { get => _user; set => SetProperty(ref _user, value); }

        public IRelayCommand SignUpCommand { get; set; }

        public EmsStudentApi emsStudentApi { get; set; }

        public Action CloseWin = null;

        private bool _isSignup = true;
        public bool IsSignup { get => _isSignup; set => SetProperty(ref _isSignup, value); }

        //Constructor:
        public StudentSignupViewModel()
        {
            SignUpCommand = new RelayCommand(signUp);
            emsStudentApi = new EmsStudentApi();
        }

        //executes the sign-up process. It first checks if all required fields are filled, and if the password and confirm password fields match.
        //It then calls the SignUpAsync() method of emsStudentApi to attempt to sign up the student with the provided data.
        //If sign-up is successful, it invokes CloseWin() to close the current window.
        private async void signUp()
        {
            IsSignup = false;

            if (string.IsNullOrEmpty(User.UserName) || string.IsNullOrEmpty(User.Password) ||
                string.IsNullOrEmpty(User.ConfirmPassword) || string.IsNullOrEmpty(User.FirstName) || string.IsNullOrEmpty(User.LastName))
            {
                IsSignup = true;
                MessageBox.Show("one or more fields empty");
                return;
            }

            else if (User.Password != User.ConfirmPassword)
            {
                IsSignup = true;
                MessageBox.Show("Password should match");
                return;
            }

            var isSignedUp = await emsStudentApi.SignUpAsync(User);
            if (isSignedUp)
                CloseWin?.Invoke();

            IsSignup = true;
        }//

    }
}
