﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Messaging;
using Exam_Management_System.Models;

namespace Exam_Management_System.ViewModel.StudentViewModels
{
    //serve as the ViewModel for the shell of the Student section of the Exam Management System.
    //It manages the currently displayed ViewModel and handles messages to switch to a different ViewModel.
    public class StudentShellViewModel : ObservableObject
    {
        private object currentViewModel;
        public object CurrentViewModel { get => currentViewModel; set { SetProperty(ref currentViewModel, value); } }

        //Contructor:
        public StudentShellViewModel()
        {
            currentViewModel = new StudentHomeViewModel();
            WeakReferenceMessenger.Default.Register<ChangeViewModelMessage>(this, (r, m) => receiveM(m));
        }

        //receives ChangeViewModelMessage messages and updates the CurrentViewModel to the ViewModel specified in the message.
        private void receiveM(ChangeViewModelMessage message)
        {
            CurrentViewModel = message.Value;
        }

    }
}
