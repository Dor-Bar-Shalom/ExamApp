﻿using Exam_Management_System.ViewModel.TeacherViewModels;
using System.Windows;

namespace Exam_Management_System.Views.TeacherViews
{
    /// <summary>
    /// Interaction logic for TeacherSignupView.xaml
    /// </summary>
    public partial class TeacherSignupView : Window
    {
        public TeacherSignupView()
        {
            InitializeComponent();
            var vm = new TeacherSignupViewModel();
            vm.CloseWin += () => Close();
            DataContext = vm;
        }
    }
}
