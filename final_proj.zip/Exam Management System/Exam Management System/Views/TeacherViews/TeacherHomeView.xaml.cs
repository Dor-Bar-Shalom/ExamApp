﻿using System.Windows.Controls;

namespace Exam_Management_System.Views.TeacherViews
{
    /// <summary>
    /// Interaction logic for TeacherHomeView.xaml
    /// </summary>
    public partial class TeacherHomeView : UserControl
    {
        public TeacherHomeView()
        {
            InitializeComponent();
        }
    }
}
