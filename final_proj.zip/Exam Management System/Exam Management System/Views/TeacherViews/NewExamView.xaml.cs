﻿using System.Windows.Controls;

namespace Exam_Management_System.Views.TeacherViews
{
    /// <summary>
    /// Interaction logic for NewExamView.xaml
    /// </summary>
    public partial class NewExamView : UserControl
    {
        public NewExamView()
        {
            InitializeComponent();
        }
    }
}
