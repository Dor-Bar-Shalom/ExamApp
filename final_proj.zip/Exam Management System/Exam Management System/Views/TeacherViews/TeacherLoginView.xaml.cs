﻿using System.Windows.Controls;

namespace Exam_Management_System.Views.TeacherViews
{
    /// <summary>
    /// Interaction logic for TeacherLoginView.xaml
    /// </summary>
    public partial class TeacherLoginView : UserControl
    {
        public TeacherLoginView()
        {
            InitializeComponent();
        }

        private void SignUp_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            var window = new TeacherSignupView();
            window.ShowDialog();
        }
    }
}
