﻿using CommunityToolkit.Mvvm.Messaging;
using Exam_Management_System.Models;
using Exam_Management_System.ViewModel;
using Exam_Management_System.ViewModel.TeacherViewModels;
using System;
using System.Windows.Controls;

namespace Exam_Management_System.Views.TeacherViews
{
    /// <summary>
    /// Interaction logic for TeacherShellView.xaml
    /// </summary>
    public partial class TeacherShellView : UserControl
    {
        public TeacherShellView()
        {
            InitializeComponent();
        }
    }
}
