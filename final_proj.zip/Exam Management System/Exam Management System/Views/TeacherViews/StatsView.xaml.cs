﻿using System.Windows;

namespace Exam_Management_System.Views.TeacherViews
{
    /// <summary>
    /// Interaction logic for StatsView.xaml
    /// </summary>
    public partial class StatsView : Window
    {
        public StatsView()
        {
            InitializeComponent();
        }
    }
}
