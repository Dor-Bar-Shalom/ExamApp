﻿using System.Windows.Controls;

namespace Exam_Management_System.Views.StudentViews
{
    /// <summary>
    /// Interaction logic for StudentShellView.xaml
    /// </summary>
    public partial class StudentShellView : UserControl
    {
        public StudentShellView()
        {
            InitializeComponent();
        }
    }
}
