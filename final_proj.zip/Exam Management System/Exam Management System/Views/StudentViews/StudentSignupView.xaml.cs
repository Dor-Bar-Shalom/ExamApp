﻿using Exam_Management_System.ViewModel.StudentViewModels;
using System.Windows;

namespace Exam_Management_System.Views.StudentViews
{
    /// <summary>
    /// Interaction logic for StudentSignupView.xaml
    /// </summary>
    public partial class StudentSignupView : Window
    {
        public StudentSignupView()
        {
            InitializeComponent();
            var vm = new StudentSignupViewModel();
            vm.CloseWin += () => Close();
            DataContext = vm;
        }
    }
}
