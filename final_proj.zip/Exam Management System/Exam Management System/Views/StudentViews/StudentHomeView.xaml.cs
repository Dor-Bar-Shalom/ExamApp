﻿using System.Windows.Controls;

namespace Exam_Management_System.Views.StudentViews
{
    /// <summary>
    /// Interaction logic for StudentHomeView.xaml
    /// </summary>
    public partial class StudentHomeView : UserControl
    {
        public StudentHomeView()
        {
            InitializeComponent();
        }
    }
}
