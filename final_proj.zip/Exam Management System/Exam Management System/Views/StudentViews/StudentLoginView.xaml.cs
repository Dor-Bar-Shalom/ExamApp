﻿using System.Windows.Controls;

namespace Exam_Management_System.Views.StudentViews
{
    /// <summary>
    /// Interaction logic for StudentLoginView.xaml
    /// </summary>
    public partial class StudentLoginView : UserControl
    {
        public StudentLoginView()
        {
            InitializeComponent();
        }

        private void SignUp_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            var window = new StudentSignupView();
            window.ShowDialog();
        }
    }
}
