﻿using CommunityToolkit.Mvvm.Messaging;
using Exam_Management_System.Models;
using Exam_Management_System.ViewModel;
using Exam_Management_System.ViewModel.StudentViewModels;
using Exam_Management_System.ViewModel.TeacherViewModels;
using System.Windows;

namespace Exam_Management_System.Views.Windows
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
            WeakReferenceMessenger.Default.Register<LoginModel>(this, (r, loginModel) => recieveCmd(loginModel));
        }

        private void recieveCmd(LoginModel loginModel)
        {
            WeakReferenceMessenger.Default.Unregister<LoginModel>(this);
            var shellWindow = new ShellWindow();
            var vm = shellWindow.DataContext as ShellViewModel;

            if (loginModel.UserType == UserType.Teacher)
                vm.SwitchVM(new TeacherShellViewModel());
            else
                vm.SwitchVM(new StudentShellViewModel());

            shellWindow.Show();
            this.Close();
        }

        private void MinimiseBtn_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
