﻿using CommunityToolkit.Mvvm.Messaging;
using Exam_Management_System.Models;
using Exam_Management_System.ViewModel;
using Exam_Management_System.ViewModel.TeacherViewModels;
using Exam_Management_System.Views.TeacherViews;
using Exam_Management_System.Views.Windows;
using System.Windows;

namespace Exam_Management_System
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class ShellWindow : Window
    {
        public ShellWindow()
        {
            InitializeComponent();
            WeakReferenceMessenger.Default.Register<LoginViewModel>(this, (r, vm) => recieveCmd(vm));
            WeakReferenceMessenger.Default.Register<StudentStatsModel>(this, (r, m) => recieveCmd(m));
        }

        private void recieveCmd(LoginViewModel vm)
        {
            WeakReferenceMessenger.Default.UnregisterAll(this);
            var win = new LoginWindow();
            win.Show();
            this.Close();
        }

        private void recieveCmd(StudentStatsModel m)
        {
            var win = new StatsView();
            var viewModel = new StatsViewModel();
            viewModel.StudentStats = m;
            viewModel.setSeris();
            win.DataContext = viewModel;
            win.ShowDialog();
        }//
    }
}
