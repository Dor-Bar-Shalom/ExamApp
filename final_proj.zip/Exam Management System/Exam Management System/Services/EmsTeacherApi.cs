﻿using Exam_Management_System.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Exam_Management_System.Services
{
    //defines methods to interact with an API for an exam management system
    public class EmsTeacherApi
    {
        private const string baseAddress = "https://localhost:7292";
        public EmsTeacherApi()
        {
        }
        //logging as teacher
        public async Task<bool> LoginAsync(LoginModel loginModel)
        {
            using (var client = new HttpClient { BaseAddress = new Uri(baseAddress) })
            {
                var json = JsonConvert.SerializeObject(loginModel);
                var data = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await client.PostAsync("/api/auth/TeacherLogin", data);

                if (response.IsSuccessStatusCode)
                {
                    var str = await response.Content.ReadAsStringAsync();
                    var status = JsonConvert.DeserializeObject<ApiStatusModel>(str);
                    setJWT(status.Message);
                    return true;
                }
                else
                    MessageBox.Show(await response.Content.ReadAsStringAsync());
                return false;
            }//
        }//
        //registering a new teacher
        public async Task<bool> SignUpAsync(UserModel userModel)
        {
            using (var client = new HttpClient { BaseAddress = new Uri(baseAddress) })
            {
                var json = JsonConvert.SerializeObject(userModel);
                var data = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await client.PostAsync("/api/auth/SignUpTeacher", data);

                if (response.IsSuccessStatusCode)
                    return true;

                MessageBox.Show(await response.Content.ReadAsStringAsync());
                return false;
            }//
        }//
        //add an exam
        public async Task<bool> AddExamAsync(ExamModel examModel)
        {
            using (var client = new HttpClient { BaseAddress = new Uri(baseAddress) })
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Properties.Settings.Default.JWT);

                var json = JsonConvert.SerializeObject(examModel);
                var data = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await client.PostAsync("/api/teacher/AddExam", data);

                if (response.IsSuccessStatusCode)
                    return true;

                MessageBox.Show("Server error");
                return false;
            }//
        }//

        //update an exam 
        //serializes the ExamModel object to JSON and creates a StringContent object with the serialized JSON data
        //sends a POST request with the JSON data
        public async Task<bool> UpdateExamAsync(ExamModel examModel)
        {
            using (var client = new HttpClient { BaseAddress = new Uri(baseAddress) })
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Properties.Settings.Default.JWT);

                var json = JsonConvert.SerializeObject(examModel);
                var data = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await client.PostAsync("/api/teacher/UpdateExam", data);

                if (response.IsSuccessStatusCode)
                    return true;

                MessageBox.Show("Server error");
                return false;
            }//
        }//
         //creates an instance of HttpClient and sets its base address to the API endpoint's address.
         // It then sets the Authorization header of the HttpClient to include the JWT token retrieved from the application settings.
         //sends a GET request to the API endpoint,If the response is successful, it deserializes the response content into a list of Exam objects. 
        public async Task<List<Exam>> SearchExamAsync(string examName)
        {
            using (var client = new HttpClient { BaseAddress = new Uri(baseAddress) })
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Properties.Settings.Default.JWT);
                var response = await client.GetAsync($"/api/teacher/SearchExams?ExamName={examName}");

                if (response.IsSuccessStatusCode)
                {
                    var exams = JsonConvert.DeserializeObject<List<Exam>>(await response.Content.ReadAsStringAsync());
                    return exams;
                }

                MessageBox.Show("Server error");
                return new List<Exam>();
            }//
        }
        //used to retrieve statistics for a specific exam
        //takes an examID parameter as input and sends an HTTP GET request
        //If the response is successful, it deserializes the JSON data from the response into a list of StudentExamStats objects
        //If not successful, it displays a message box with an error
        public async Task<StudentStatsModel> ExamStatsAsync(int examID)
        {
            using (var client = new HttpClient { BaseAddress = new Uri(baseAddress) })
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Properties.Settings.Default.JWT);
                var response = await client.GetAsync($"/api/teacher/ExamStats?ExamID={examID}");

                if (response.IsSuccessStatusCode)
                {
                    var stats = JsonConvert.DeserializeObject<List<StudentExamStats>>(await response.Content.ReadAsStringAsync());
                    return new StudentStatsModel { ExamStats = stats };
                }

                MessageBox.Show("Server error");
                return new StudentStatsModel();
            }//
        }

        //sets the JWT token received from the server in the application settings, so that it can be used in subsequent API requests.
        //It takes a single parameter jwt, which is the JWT token received from the server,
        //and saves it in the application settings using Properties.Settings.Default.JWT = jwt.
        //The Properties.Settings.Default.Save() method is then called to save the changes to the settings.
        //This allows the JWT token to be accessed and used in other parts of the application.
        private void setJWT(string jwt)
        {
            Properties.Settings.Default.JWT = jwt;
            Properties.Settings.Default.Save();
        }//
    }
}
