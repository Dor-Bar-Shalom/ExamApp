﻿using Exam_Management_System.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Exam_Management_System.Services
{
    public class EmsStudentApi
    {
        private const string baseAddress = "https://localhost:7292";

        public EmsStudentApi()
        {

        }//
        //logging as student
        public async Task<bool> LoginAsync(LoginModel loginModel)
        {
            using (var client = new HttpClient { BaseAddress = new Uri(baseAddress) })
            {
                var json = JsonConvert.SerializeObject(loginModel);
                var data = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await client.PostAsync("/api/auth/StudentLogin", data);

                if (response.IsSuccessStatusCode)
                {
                    var str = await response.Content.ReadAsStringAsync();
                    var status = JsonConvert.DeserializeObject<ApiStatusModel>(str);
                    setJWT(status.Message, loginModel.UserName);
                    return true;
                }
                else
                    MessageBox.Show(await response.Content.ReadAsStringAsync());
                return false;
            }//
        }//
        //registering a new student
        public async Task<bool> SignUpAsync(UserModel userModel)
        {
            using (var client = new HttpClient { BaseAddress = new Uri(baseAddress) })
            {
                var json = JsonConvert.SerializeObject(userModel);
                var data = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await client.PostAsync("/api/auth/SignUpStudent", data);

                if (response.IsSuccessStatusCode)
                    return true;

                MessageBox.Show(await response.Content.ReadAsStringAsync());
                return false;
            }//
        }//
        //searching for exams
        public async Task<List<Exam>> SearchExamAsync(string examName)
        {
            using (var client = new HttpClient { BaseAddress = new Uri(baseAddress) })
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Properties.Settings.Default.JWT);
                var response = await client.GetAsync($"/api/student/SearchExams?ExamName={examName}");

                if (response.IsSuccessStatusCode)
                {
                    var exams = JsonConvert.DeserializeObject<List<Exam>>(await response.Content.ReadAsStringAsync());
                    return exams;
                }

                MessageBox.Show("Server error");
                return new List<Exam>();
            }//
        }//
        //getting information about an exam
        public async Task<bool> ExamInfoAsync(int examID)
        {
            using (var client = new HttpClient { BaseAddress = new Uri(baseAddress) })
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Properties.Settings.Default.JWT);
                var response = await client.GetAsync($"/api/student/ExamInfo?ExamID={examID}");

                if (response.IsSuccessStatusCode)
                    return true;

                return false;
            }//
        }//
        //submit an exam
        public async Task<bool> SubmitExam(Exam exam)
        {
            using (var client = new HttpClient { BaseAddress = new Uri(baseAddress) })
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Properties.Settings.Default.JWT);
                var json = JsonConvert.SerializeObject(exam);
                var data = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await client.PostAsync("/api/student/SubmitExam", data);

                if (response.IsSuccessStatusCode)
                    return true;

                return false;
            }//
        }//
        //storing the JWT and username in the application settings
        //JWTs are stateless, which means that the server does not need to maintain any state information about the user.
        private void setJWT(string jwt, string username)
        {
            Properties.Settings.Default.JWT = jwt;
            Properties.Settings.Default.UserName = username;
            Properties.Settings.Default.Save();
        }//
    }
}
