﻿using CommunityToolkit.Mvvm.ComponentModel;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;

namespace Exam_Management_System.Models
{
    //represents a single exam.
    public class ExamModel
    {
        public int ID { get; set; } = -1;
        public string ExamJson { get; set; } = string.Empty;
    }

    //represents a complete exam
    public class Exam
    {
        public int ID { get; set; } = -1;
        public string Name { get; set; } = string.Empty;
        public DateTime Date { get; set; } = DateTime.Now;
        public string NameOfTeacher { get; set; } = string.Empty;
        public string BeginningTime { get; set; } = string.Empty;
        public string EndTime { get; set; } = string.Empty;
        public bool IsRandomOrderYes { get; set; } = true;
        public bool IsRandomOrderNo { get; set; } = false;

        //representing the questions in the exam:
        public ObservableCollection<QuestionModel> Questions { get; set; } = new ObservableCollection<QuestionModel>();
    }

    //represents a single question:
    public class QuestionModel : ObservableObject
    {
        public string Question { get; set; } = string.Empty;
        public bool IsText { get; set; } = true;
        public bool IsImage { get; set; } = false;
        public string ImageUrl { get; set; } = string.Empty;
        public ObservableCollection<string> Options { get; set; } = new ObservableCollection<string>();

        private string _rightAnsIndex = string.Empty;
        public string RightAnsIndex
        {
            get => _rightAnsIndex;
            set
            {
                int number = 0;
                var isInt = int.TryParse(value, out number);
                if (isInt && (number <= Options.Count && number > 0))
                {
                    _rightAnsIndex = number.ToString();
                    Ops = Options[number - 1];
                }
            }
        }

        private string _ops = string.Empty;
        public string Ops { get => _ops; set => SetProperty(ref _ops, value); }

        public int SelectedIndex { get; set; } = -1;
        public bool IsRandomOptions { get; set; } = true;
    }
}
