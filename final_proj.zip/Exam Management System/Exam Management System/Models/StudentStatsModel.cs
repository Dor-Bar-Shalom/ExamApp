﻿using System.Collections.Generic;

namespace Exam_Management_System.Models
{

    //every exam will hold a list of the students names that did exams and thier grades:
    public class StudentStatsModel
    {
        public string ExamName { get; set; } = string.Empty;
        public List<StudentExamStats> ExamStats { get; set; } = new List<StudentExamStats>();
    }

    public class StudentExamStats
    {
        public string StudentName { get; set; } = string.Empty;
        public int Percentage { get; set; }
    }
}
