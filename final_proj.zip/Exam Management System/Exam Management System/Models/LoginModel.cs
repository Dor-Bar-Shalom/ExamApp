﻿namespace Exam_Management_System.Models
{
    public enum UserType
    {
        Student,
        Teacher
    }

    // represents the user's login credentials:
    public class LoginModel
    {
        public string UserName { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public UserType UserType { get; set; }
    }

}
