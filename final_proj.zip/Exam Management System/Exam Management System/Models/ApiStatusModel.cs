﻿namespace Exam_Management_System.Models
{
    //provide a data structure that can be used to represent the status and message returned by an API endpoint in a .NET application.
    //This class is designed to be used as a model for deserializing the response from the API into an object that can be easily
    //consumed by the application code.
    public class ApiStatusModel
    {
        // Initialized to an empty string by default using the null coalescing operator.
        public string StatusCode { get; set; } = string.Empty;
        //also initialized to an empty string by default using the null coalescing operator.
        public string Message { get; set; } = string.Empty;
    }
}
