﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Messaging.Messages;

namespace Exam_Management_System.Models
{

    //a custom message class that helps to send a message from one view model to another,
    //indicating that the view model associated with a particular view should be changed.
    public class ChangeViewModelMessage : ValueChangedMessage<ObservableObject>
    {
        public ChangeViewModelMessage(ObservableObject viewModel) : base(viewModel)
        {
        }
    }
}
