﻿using ExamManagementAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace ExamManagementAPI.Data
{
    //define the database context for the Exam Management API
    //provides properties for each of the database tables used by the application.
    public class EMContext : DbContext
    {
        public DbSet<TeacherModel> Teachers { get; set; }
        public DbSet<StudentModel> Students { get; set; }
        public DbSet<ExamModel> Exams { get; set; }
        public DbSet<StudentExamResult> ExamErrors { get; set; }

        //configure the database connection settings.
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Data Source=Barsha\SQLEXPRESS;Initial Catalog=EmDB;Integrated Security=True;TrustServerCertificate=True");
        }
    }
}
