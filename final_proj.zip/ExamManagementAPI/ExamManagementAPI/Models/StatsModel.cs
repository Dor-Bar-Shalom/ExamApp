﻿namespace ExamManagementAPI.Models
{
    //store the exam statistics of a student.
    public class StudentExamStats
    {
        public string StudentName { get; set; } = string.Empty;
        public int Percentage { get; set; }
    }
}
