﻿using System.ComponentModel.DataAnnotations;

namespace ExamManagementAPI.Models
{
    //contains properties to store the results of a student's exam
    public class StudentExamResult
    {
        [Key]
        public int Id { get; set; }
        public int examineeID { get; set; }
        public string examineeName { get; set; } = string.Empty;
        public int ExamID { get; set; }
        public int Percentage { get; set; }
        public string Grade { get; set; } = string.Empty;
        public string ExamErrorJson { get; set; } = string.Empty;
    }//

    //contains properties to store information about errors that occurred during an exam
    public class ExamErrorModel
    {
        public string QuestionName { get; set; } = string.Empty;
        public string IncorrectAnsChoosen { get; set; } = string.Empty;
        public string RightAnswer { get; set; } = string.Empty;
    }//
}