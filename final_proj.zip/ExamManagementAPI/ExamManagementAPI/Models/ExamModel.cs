﻿using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;

////define the model classes for exams and questions in the Exam Management API.
namespace ExamManagementAPI.Models
{
    //represents the exam entity that will be stored in the database.
    public class ExamModel
    {
        [Key]
        public int ID { get; set; }
        public string ExamJson { get; set; } = string.Empty;
    }

    //represents an exam that will be created by a teacher
    public class Exam
    {
        public int ID { get; set; }
        public string Name { get; set; } = string.Empty;
        public DateTime Date { get; set; }
        public string NameOfTeacher { get; set; } = string.Empty;
        public string BeginningTime { get; set; } = string.Empty;
        public string EndTime { get; set; } = string.Empty;
        public bool IsRandomOrderYes { get; set; } = true;
        public bool IsRandomOrderNo { get; set; } = false;
        public List<QuestionModel> Questions { get; set; } = new List<QuestionModel>();
    }

    //represents a single question in an exam
    public class QuestionModel
    {
        public string Question { get; set; } = string.Empty;
        public bool IsText { get; set; } = true;
        public bool IsImage { get; set; } = false;
        public string ImageUrl { get; set; } = string.Empty;
        public List<string> Options { get; set; } = new List<string>();
        public string RightAnsIndex { get; set; } = string.Empty;
        public int SelectedIndex { get; set; } = -1;
        public bool IsRandomOptions { get; set; } = true;
    }

}
