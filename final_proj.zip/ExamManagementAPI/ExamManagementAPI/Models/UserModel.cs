﻿using System.ComponentModel.DataAnnotations;

namespace ExamManagementAPI.Models
{
    public enum UserType
    {
        Student,
        Teacher
    }

    // A Pattern for a FORM of an new user.
    public class UserModel
    {
        [Key]
        public int Id { get; set; }
        public string UserName { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }

    public class StudentModel : UserModel
    {
    }

    public class TeacherModel : UserModel
    {
    }

  // A Pattern for a FORM of an existing user.
    public class LoginModel
    {
        public string UserName { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }
}
