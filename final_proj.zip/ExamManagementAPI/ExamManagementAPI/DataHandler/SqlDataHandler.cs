﻿using ExamManagementAPI.Data;
using ExamManagementAPI.Models;
using Newtonsoft.Json;

namespace ExamManagementAPI.DataHandler
{
    public class SqlDataHandler
    {
        public SqlDataHandler()
        {

        }

        // verify username and password for login using UserRoles
        public bool VerifyUser(LoginModel model, UserType userType)
        {
            using (var context = new EMContext())
            {
                if (userType == UserType.Teacher)
                {
                    var teacher = context.Teachers.FirstOrDefault(obj => obj.UserName == model.UserName && obj.Password == model.Password);

                    if (teacher == null)
                        return false;
                }//
                else
                {
                    var student = context.Students.FirstOrDefault(obj => obj.UserName == model.UserName && obj.Password == model.Password);

                    if (student == null)
                        return false;
                }//
                return true;
            }//
        }//

        // check if user name already exisit in DB:
        public bool CheckUsername(UserModel model, UserType userType)
        {
            using (var context = new EMContext())
            {
                if (userType == UserType.Teacher)
                {
                    var teacher = context.Teachers.FirstOrDefault(obj => obj.UserName == model.UserName);

                    if (teacher == null)
                        return false;
                }//
                else
                {
                    var student = context.Students.FirstOrDefault(obj => obj.UserName == model.UserName);

                    if (student == null)
                        return false;
                }//
                return true;
            }//
        }//

        public void AddTeacher(TeacherModel model)
        {
            using (var context = new EMContext())
            {
                context.Teachers.Add(model);
                context.SaveChanges();
            }
        }//

        public void AddStudent(StudentModel model)
        {
            using (var context = new EMContext())
            {
                context.Students.Add(model);
                context.SaveChanges();
            }
        }//

        //Search for an exam, teacher interface version:
        public List<Exam> TeacherExamSearch(string examName)
        {
            using (var context = new EMContext())
            {
                var exams = new List<Exam>();
                foreach (var exam in context.Exams)
                {
                    var obj = JsonConvert.DeserializeObject<Exam>(exam.ExamJson);
                    if (obj.Name.ToLower().Contains(examName.ToLower()))
                    {
                        obj.ID = exam.ID;
                        exams.Add(obj);
                    }//
                }//
                return exams;
            }//
        }//

        public Exam GetExamByID(int id)
        {
            using (var context = new EMContext())
            {
                var obj = context.Exams.FirstOrDefault(obj => obj.ID == id);
                var exam = JsonConvert.DeserializeObject<Exam>(obj.ExamJson);
                return exam;
            }
        }

        //Search for an exam, student interface version (with no solotions):
        public List<Exam> StudentExamSearch(string examName)
        {
            using (var context = new EMContext())
            {
                var exams = new List<Exam>();
                foreach (var exam in context.Exams)
                {
                    var obj = JsonConvert.DeserializeObject<Exam>(exam.ExamJson);
                    if (obj.Name.ToLower().Contains(examName.ToLower()))
                    {
                        obj.ID = exam.ID;
                        foreach (var question in obj.Questions)
                            question.RightAnsIndex = string.Empty;

                        exams.Add(obj);
                    }//
                }//
                return exams;
            }//
        }//

        //checks whether a student has already taken a given exam or not:
        public bool StudentExamStatus(int examID, string userName)
        {
            using (var context = new EMContext())
            {
                var student = context.Students.FirstOrDefault(obj => obj.UserName == userName);
                var examResult = context.ExamErrors.FirstOrDefault(obj => obj.ExamID == examID && obj.examineeID == student.Id);

                if (examResult == null)
                    return false;
                else return true;
            }//
        }//

        //takes an 'ExamModel' object as input, and adds the exam to the database:
        public void AddExam(ExamModel exam)
        {
            using (var context = new EMContext())
            {
                context.Exams.Add(new ExamModel { ExamJson = exam.ExamJson });
                context.SaveChanges();
            }//
        }//

        //getting student ID by name:
        private int GetStudentID(string username)
        {
            using (var context = new EMContext())
            {
                var user = context.Students.FirstOrDefault(obj => obj.UserName == username);
                return user.Id;
            }//
        }//

        //takes an Exam object and a username as input
        //and calculates the student's score and exam result
        //then adds the exam result to the database:
        public void SubmitExam(Exam exam, string username)
        {
            using (var context = new EMContext())
            {
                var userID = GetStudentID(username);
                var examAns = GetExamByID(exam.ID);

                double correctAns = 0;
                double quesTotal = exam.Questions.Count;
                var errors = new List<ExamErrorModel>();

                for (int i = 0; i < quesTotal; ++i)
                {
                    var examA = examAns.Questions.FirstOrDefault(obj => obj.Question == exam.Questions[i].Question);

                    if (string.IsNullOrEmpty(examA.RightAnsIndex))
                        examA.RightAnsIndex = "0";

                    var rightAnsIndex = int.Parse(examA.RightAnsIndex);

                    var ans = (exam.Questions[i].SelectedIndex != -1) ? exam.Questions[i].Options[exam.Questions[i].SelectedIndex] : string.Empty;

                    if (ans == examA.Options[rightAnsIndex - 1])
                        ++correctAns;
                    else
                    {
                        errors.Add(new ExamErrorModel
                        {
                            QuestionName = exam.Questions[i].Question,
                            RightAnswer = examA.Options[rightAnsIndex - 1],
                            IncorrectAnsChoosen = ans
                        });
                    }
                }

                var percentage = (correctAns / quesTotal) * 100.0;
                var studentExamResult = new StudentExamResult
                {
                    ExamErrorJson = JsonConvert.SerializeObject(errors),
                    ExamID = exam.ID,
                    examineeID = userID,
                    Percentage = (int)percentage,
                    examineeName = GetStudentName(userID),
                    Grade = GenerateGrade((int)percentage)
                };
                context.ExamErrors.Add(studentExamResult);
                context.SaveChanges();
            }//
        }

        //generate an alphabetic answer from the numerical grade:
        private string GenerateGrade(int percentage)
        {
            if (percentage >= 80 && percentage <= 100)
                return "A";
            else if (percentage >= 60 && percentage <= 79)
                return "B";
            else if (percentage >= 50 && percentage <= 59)
                return "C";
            else if (percentage >= 40 && percentage <= 49)
                return "D";
            else if (percentage >= 30 && percentage <= 39)
                return "E";
            else
                return "F";
        }

        //updating details in the exam and save it in the DB: 
        public void UpdateExam(ExamModel exam)
        {
            using (var context = new EMContext())
            {
                var examObj = JsonConvert.DeserializeObject<ExamModel>(exam.ExamJson);
                var obj = context.Exams.FirstOrDefault(obj => obj.ID == examObj.ID);
                if (obj != null)
                {
                    obj.ExamJson = exam.ExamJson;
                    context.SaveChanges();
                }
            }//
        }//

        //get student name by ID:
        private string GetStudentName(int id)
        {
            using (var context = new EMContext())
            {
                var student = context.Students.FirstOrDefault(obj => obj.Id == id);
                return student?.FirstName + " " + student?.LastName;
            }
        }

        // retrieves the exam error results from a database for a specified exam ID
        //and creates a list of StudentExamStats objects containing the percentage
        //and examinee name for each result then returns the list of StudentExamStats:
        public List<StudentExamStats> GetStats(int examID)
        {
            using (var context = new EMContext())
            {
                var results = context.ExamErrors.Where(obj => obj.ExamID == examID).ToList();
                var stats = new List<StudentExamStats>();
                foreach (var result in results)
                    stats.Add(new StudentExamStats { Percentage = result.Percentage, StudentName = result.examineeName });

                return stats;
            }
        }//

    }
}
