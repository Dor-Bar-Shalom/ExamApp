﻿using ExamManagementAPI.DataHandler;
using ExamManagementAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Security.Claims;

namespace ExamManagementAPI.Controllers
{
    //handle HTTP requests related to student functionalities in an Exam Management API.
    [Route("api/student")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private SqlDataHandler sqlDataHandler;

        public StudentController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            sqlDataHandler = new SqlDataHandler();
        }//

        //Searching an exam by it name, returns a list of exams with matching name:
        [HttpGet("SearchExams"), Authorize(Roles = "Student")]
        public List<Exam> SearchExams(string ExamName)
        {
            var exams = sqlDataHandler.StudentExamSearch(ExamName);
            return exams;
        }//

        //Checks if the status of a student in a specific exam:
        [HttpGet("ExamInfo"), Authorize(Roles = "Student")]
        public ActionResult ExamInfo(int ExamID)
        {
            var userName = string.Empty;
            if (_httpContextAccessor.HttpContext != null)
                userName = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);

            var status = sqlDataHandler.StudentExamStatus(ExamID, userName);

            if (status == false)
                return new OkObjectResult(new { StatusCode = "OK", Message = "Exam not taken" });

            else
                return BadRequest($"Exam already taken by you.");
        }//


        //receives an Exam object and submits it to the database with the name of the authenticated student.
        //returns a message indicating that the exam has been successfully submitted.
        //requires authorization as a "Student" role.
        [HttpPost("SubmitExam"), Authorize(Roles = "Student")]

        public ActionResult SubmitExam(Exam exam)
        {
            var userName = string.Empty;
            if (_httpContextAccessor.HttpContext != null)
                userName = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Name);

            sqlDataHandler.SubmitExam(exam, userName);
            return new OkObjectResult(new { StatusCode = "OK", Message = "Exam Submitted" });
        }//


    }
}
