﻿using ExamManagementAPI.DataHandler;
using ExamManagementAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ExamManagementAPI.Controllers
{
    //handle requests related to exam management, specifically for teachers.
    [Route("api/teacher")]
    [ApiController]
    public class TeacherController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private SqlDataHandler sqlDataHandler;


        //Constractor:
        public TeacherController(IConfiguration configuration)
        {
            _configuration = configuration;
            sqlDataHandler = new SqlDataHandler();
        }//

        //search for an exam in the DB, accessable only for teachers:
        [HttpGet("SearchExams"), Authorize(Roles = "Admin")]
        public List<Exam> SearchExams(string ExamName)
        {
            var exams = sqlDataHandler.TeacherExamSearch(ExamName);
            return exams;
        }//

        //searching for an exam status by giving exam ID, accessable only for teachers:
        [HttpGet("ExamStats"), Authorize(Roles = "Admin")]
        public List<StudentExamStats> ExamStats(int ExamID)
        {
            var stats = sqlDataHandler.GetStats(ExamID);
            return stats;
        }//


        //Adding a new exam, accessable only for teachers:
        [HttpPost("AddExam"), Authorize(Roles = "Admin")]
        public ActionResult AddExam(ExamModel exam)
        {
            sqlDataHandler.AddExam(exam);
            return new OkObjectResult(new { StatusCode = "OK", Message = "Exam Added" });
        }//

        //Editing an existing exam, accessable only for teachers:
        [HttpPost("UpdateExam"), Authorize(Roles = "Admin")]
        public ActionResult UpdateExam(ExamModel exam)
        {
            sqlDataHandler.UpdateExam(exam);
            return new OkObjectResult(new { StatusCode = "OK", Message = "Exam Updated" });
        }//
    }
}
