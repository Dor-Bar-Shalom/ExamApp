﻿using ExamManagementAPI.DataHandler;
using ExamManagementAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace ExamManagementAPI.Controllers
{
    //controller class for handling authentication-related API requests in an Exam Management System.
    [Route("api/auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private SqlDataHandler sqlDataHandler;
        public AuthController(IConfiguration configuration)
        {
            _configuration = configuration;
            sqlDataHandler = new SqlDataHandler();
        }//

        //register student:
        [HttpPost("SignUpStudent")]
        public ActionResult SignUpStudent(UserModel userModel)
        {
            if (sqlDataHandler.CheckUsername(userModel, UserType.Student)) // check if username exist
                return BadRequest("Username exists");

            sqlDataHandler.AddStudent(new StudentModel
            {
                FirstName = userModel.FirstName,
                LastName = userModel.LastName,
                Password = userModel.Password,
                UserName = userModel.UserName
            }); // insert to DB

            return new OkObjectResult(new { StatusCode = "OK", Message = "Student Registered Successfully" });
        }//

        //register teacher:
        [HttpPost("SignUpTeacher")]
        public ActionResult SignUpTeacher(UserModel userModel)
        {
            if (sqlDataHandler.CheckUsername(userModel, UserType.Teacher)) // check if username exist
                return BadRequest("Username exists");

            sqlDataHandler.AddTeacher(new TeacherModel
            {
                FirstName = userModel.FirstName,
                LastName = userModel.LastName,
                Password = userModel.Password,
                UserName = userModel.UserName
            }); // insert to DB

            return new OkObjectResult(new { StatusCode = "OK", Message = "Teacher Registered Successfully" });
        }//

        //Authenticates a student user and returns a JWT token if successful
        [HttpPost("StudentLogin")]
        public ActionResult<string> StudentLogin(LoginModel model)
        {
            if (sqlDataHandler.VerifyUser(model, UserType.Student) == false) // verify username and password
                return BadRequest("login failed.");

            string token = CreateToken(model, UserType.Student); // create JWT Token
            return new OkObjectResult(new { StatusCode = "OK", Message = token });
        }//

        //Authenticates a teacher user and returns a JWT token if successful
        [HttpPost("TeacherLogin")]
        public ActionResult<string> TeacherLogin(LoginModel model)
        {
            if (sqlDataHandler.VerifyUser(model, UserType.Teacher) == false) // verify username and password
                return BadRequest("login failed.");

            string token = CreateToken(model, UserType.Teacher);// create JWT Token
            return new OkObjectResult(new { StatusCode = "OK", Message = token });
        }//

        // cretae JWT Auth token 
        private string CreateToken(LoginModel userAuth, UserType userRoles)
        {
            List<Claim> claims = new List<Claim>();
            claims.Add(new Claim(ClaimTypes.Name, userAuth.UserName)); // add username to claim data

            // set Teacher role to admin in claim
            if (userRoles == UserType.Teacher)
                claims.Add(new Claim(ClaimTypes.Role, "Admin"));

            // set Teacher role to employee in claim
            else
                claims.Add(new Claim(ClaimTypes.Role, "Student"));

            var key = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes(_configuration.GetSection("AppSettings:Token").Value));

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);

            var token = new JwtSecurityToken(
                claims: claims,
                expires: DateTime.Now.AddDays(2), // set the expiry date to 2day
                signingCredentials: creds);

            var jwt = new JwtSecurityTokenHandler().WriteToken(token);

            return jwt;
        }//

    }
}
